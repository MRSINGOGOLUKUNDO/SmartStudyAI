Drop up to 10 study photos here, named exactly:
study_1.jpg, study_2.jpg ... study_10.jpg
(lowercase, ~1080x1920 or 1440x2560, under ~400 KB each).
The dashboard slideshow picks them up automatically. With none present it shows a navy gradient.
